/**
 * 
 */
/**
 * @author nlasz
 *
 */
module campuscafe {
}