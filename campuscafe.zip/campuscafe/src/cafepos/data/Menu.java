package cafepos.data;

import java.util.ArrayList;
import java.util.List;
import cafepos.model.Product;
import cafepos.model.Beverage;
import cafepos.model.Food;
import cafepos.model.Size;

public class Menu {
    private List<Product> products;

    public Menu() {
        products = new ArrayList<>();
        loadDefaultMenu();
    }

    // Add a product manually (if needed)
    public void addProduct(Product product) {
        if (product == null) {
            throw new IllegalArgumentException("Product cannot be null");
        }
        products.add(product);
    }

    // Get product by index (1-based for user friendliness)
    public Product getProductByIndex(int index) {
        if (index <= 0 || index > products.size()) {
            throw new IllegalArgumentException("Invalid product index");
        }
        return products.get(index - 1);
    }

    // Get product by code (id field)
    public Product getProductByCode(String code) {
        for (Product p : products) {
            if (p.getId().equalsIgnoreCase(code)) {
                return p;
            }
        }
        throw new IllegalArgumentException("Invalid product code: " + code);
    }

    // Display the menu
    public void displayMenu() {
        System.out.println("=== Café Menu ===");
        for (int i = 0; i < products.size(); i++) {
            System.out.println((i + 1) + ". " + products.get(i).getDisplayName());
        }
    }

    // Preload some default items
    private void loadDefaultMenu() {
    	// Example beverages
    	addProduct(new Beverage("B1", "Coffee", new java.math.BigDecimal("2.00"), Size.SMALL));
    	addProduct(new Beverage("B2", "Latte", new java.math.BigDecimal("3.00"), Size.MEDIUM));
    	addProduct(new Beverage("B3", "Iced Tea", new java.math.BigDecimal("2.50"), Size.LARGE));


        // Example foods
        addProduct(new Food("F1", "Sandwich", new java.math.BigDecimal("4.00")));
        addProduct(new Food("F2", "Salad", new java.math.BigDecimal("3.50"), true, false));
    }
}