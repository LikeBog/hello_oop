package cafepos;

import cafepos.data.Menu;
import cafepos.model.LineItem;
import cafepos.model.Order;
import cafepos.model.Product;
import cafepos.model.Size;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Menu menu = new Menu();
        Order order = new Order();
        Scanner scanner = new Scanner(System.in);
        boolean ordering = true;

        System.out.println("Welcome to the Campus Café!");

        while (ordering) {
            menu.displayMenu();
            System.out.println("Enter product number (or code) to add to order, or '0' to finish:");
            String input = scanner.nextLine().trim();

            if (input.equals("0")) {
                ordering = false;
                break;
            }

            Product selectedProduct = null;

            // Try to parse as a number first
            try {
                int index = Integer.parseInt(input);
                selectedProduct = menu.getProductByIndex(index);
            } catch (NumberFormatException e) {
                // Not a number, try by code
                try {
                    selectedProduct = menu.getProductByCode(input);
                } catch (IllegalArgumentException ex) {
                    System.out.println("Invalid product code. Try again.");
                    continue;
                }
            } catch (IllegalArgumentException e) {
                System.out.println("Invalid product number. Try again.");
                continue;
            }

            // Ask for quantity
            System.out.println("Enter quantity:");
            int quantity;
            try {
                quantity = Integer.parseInt(scanner.nextLine().trim());
                if (quantity <= 0) {
                    System.out.println("Quantity must be greater than 0.");
                    continue;
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid quantity. Try again.");
                continue;
            }

            // If the product is a beverage, ask for size
            if (selectedProduct instanceof cafepos.model.Beverage) {
                System.out.println("Select size (SMALL, MEDIUM, LARGE):");
                String sizeInput = scanner.nextLine().trim().toUpperCase();
                try {
                    Size size = Size.valueOf(sizeInput);
                    ((cafepos.model.Beverage) selectedProduct).setSize(size);
                } catch (IllegalArgumentException e) {
                    System.out.println("Invalid size. Defaulting to MEDIUM.");
                    ((cafepos.model.Beverage) selectedProduct).setSize(Size.MEDIUM);
                }
            }

            // Add to order
            order.addItem(new LineItem(selectedProduct, quantity));
            System.out.println(quantity + " × " + selectedProduct.getDisplayName() + " added to order.\n");
        }

        // Print final receipt
        System.out.println("\n=== Final Receipt ===");
        System.out.println(order);
        System.out.println("Thank you for your order!");
        scanner.close();
    }
}
