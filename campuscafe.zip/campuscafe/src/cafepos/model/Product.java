package cafepos.model;

import java.math.BigDecimal;

public abstract class Product 
{
	private String id; 
    private String name;
    private BigDecimal basePrice;

    public Product(String id, String name, BigDecimal basePrice) 
    {
    	setId(id);
        setName(name);
        setBasePrice(basePrice);
    }
    
    public void setId(String id) {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("ID cannot be empty");
        }
        this.id = id;
    }

    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Name cannot be empty");
        }
        this.name = name;
    }

    public void setBasePrice(BigDecimal basePrice) {
        if (basePrice == null || basePrice.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Base price cannot be negative");
        }
        this.basePrice = basePrice;
    }
    
    public String getId() {return id; }
    public String getName() { return name; }
    public BigDecimal getBasePrice() { return basePrice; }

 // Menu printing
    public String getDisplayName() {
    	return id + ": " + name + " - $" + String.format("%.2f", basePrice.doubleValue());
    }

    @Override
    public String toString() {
        return getDisplayName();
    }

    // Subclasses must implement pricing logic
    public abstract BigDecimal price();
    
}
    