package cafepos.model;

import java.math.BigDecimal;

public class LineItem {
	
	private Product product;
	private int quantity;
	
	public LineItem(Product product, int quantity) {
		setProduct(product);
		setQuantity(quantity);
	}
	
	public Product getProduct() {
		return product;
	}
	
	public void setProduct(Product product) {
		if (product == null) {
			throw new IllegalArgumentException("Product cannot be null");
		}
		this.product = product;
	}
	
	public int getQuantity() {
		return quantity;
	}
	
	public void setQuantity(int quantity) {
		if (quantity <= 0) {
			throw new IllegalArgumentException("Quantity must be greater than zero.");
			
		}
		this.quantity = quantity;
	}
	
	public BigDecimal lineTotal() {
		return product.price().multiply(new BigDecimal(quantity));
		
	}
	public String toString() {
		return quantity + " x " + product.getDisplayName() +
				" = $" + String.format("%.2f", lineTotal().doubleValue());
		
	}
}