package cafepos.model;

import java.math.BigDecimal;

public class Food extends Product {

    private boolean extraCheese;
    private boolean glutenFree;

    public Food(String id, String name, BigDecimal basePrice) {
        this(id, name, basePrice, false, false);
    }

    public Food(String id, String name, BigDecimal basePrice, boolean extraCheese, boolean glutenFree) {
        super(id, name, basePrice);
        this.extraCheese = extraCheese;
        this.glutenFree = glutenFree;
    }

    public boolean hasExtraCheese() { return extraCheese; }
    public void setExtraCheese(boolean extraCheese) { this.extraCheese = extraCheese; }

    public boolean isGlutenFree() { return glutenFree; }
    public void setGlutenFree(boolean glutenFree) { this.glutenFree = glutenFree; }

    @Override
    public BigDecimal price() {
        BigDecimal finalPrice = getBasePrice();
        if (extraCheese) finalPrice = finalPrice.add(new BigDecimal("0.50"));
        if (glutenFree) finalPrice = finalPrice.add(new BigDecimal("1.00"));
        return finalPrice;
    }

    @Override
    public String getDisplayName() {
        StringBuilder addOns = new StringBuilder();
        if (extraCheese) addOns.append("Extra Cheese ");
        if (glutenFree) addOns.append("Gluten-Free ");
        String addOnText = addOns.length() > 0 ? "(" + addOns.toString().trim() + ")" : "";
        return getId() + ": " + getName() + " " + addOnText + " - $" + String.format("%.2f", price().doubleValue());
    }
}