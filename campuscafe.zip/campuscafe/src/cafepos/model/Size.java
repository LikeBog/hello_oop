package cafepos.model;

import java.math.BigDecimal;

public enum Size {
    SMALL(new BigDecimal("1.0")),
    MEDIUM(new BigDecimal("1.25")),
    LARGE(new BigDecimal("1.5"));

    private final BigDecimal multiplier;

    Size(BigDecimal multiplier) {
        this.multiplier = multiplier;
    }

    public BigDecimal getMultiplier() {
        return multiplier;
    }
}