package cafepos.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.math.RoundingMode;

public final class Order {

    private List<LineItem> items;
    private static final BigDecimal TAX_RATE = new BigDecimal("0.08"); // 8% sales tax

    public Order() {
        this.items = new ArrayList<>();
    }

    public void addItem(LineItem item) {
        if (item == null) {
            throw new IllegalArgumentException("LineItem cannot be null");
        }
        items.add(item);
    }

    public void removeItem(LineItem item) {
        items.remove(item);
    }

    public List<LineItem> getItems() {
        return new ArrayList<>(items); // defensive copy
    }

    public BigDecimal subtotal() {
        BigDecimal total = BigDecimal.ZERO;
        for (LineItem item : items) {
            total = total.add(item.lineTotal());
        }
        return total;
    }

    public BigDecimal tax() {
    	return subtotal().multiply(TAX_RATE).setScale(2, RoundingMode.HALF_UP);
    }

    public BigDecimal total() {
    	return subtotal().add(tax()).setScale(2, RoundingMode.HALF_UP);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Order Summary:\n");
        for (LineItem item : items) {
            sb.append(item).append("\n");
        }
        sb.append("Subtotal: $").append(String.format("%.2f", subtotal())).append("\n");
        sb.append("Tax: $").append(String.format("%.2f", tax())).append("\n");
        sb.append("Total: $").append(String.format("%.2f", total()));
        return sb.toString();
    }
}