package cafepos.model;

import java.math.BigDecimal;

public class Beverage extends Product {

    private Size size; // constant field for each beverage

    // Constructor that takes Size
    public Beverage(String id, String name, BigDecimal basePrice, Size size) {
        super(id, name, basePrice);
        setSize(size);
    }

    // Optional default constructor (MEDIUM)
    public Beverage(String id, String name, BigDecimal basePrice) {
        this(id, name, basePrice, Size.MEDIUM);
    }

    public Size getSize() {
        return size;
    }

    public void setSize(Size size) {
        if (size == null) {
            throw new IllegalArgumentException("Size cannot be null");
        }
        this.size = size;
    }

    @Override
    public BigDecimal price() {
        return getBasePrice().multiply(size.getMultiplier());
    }

    @Override
    public String getDisplayName() {
        return getId() + ": " + getName() + " (" + size.name() + ") - $" 
               + String.format("%.2f", price().doubleValue());
    }
}
