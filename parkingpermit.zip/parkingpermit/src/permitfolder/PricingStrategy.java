package permitfolder;

import java.math.BigDecimal;

public interface PricingStrategy {
    BigDecimal baseMonthly(PermitSelection sel);
}
