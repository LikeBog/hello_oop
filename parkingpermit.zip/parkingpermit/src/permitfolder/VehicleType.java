package permitfolder;
	
public enum VehicleType {	
    CAR, SUV, MOTORCYCLE
}
