package permitfolder;

import java.math.BigDecimal;

public class ResidentPricingStrategy implements PricingStrategy {
    public BigDecimal baseMonthly(PermitSelection sel) {
        return new BigDecimal("45.00");
    }
}
