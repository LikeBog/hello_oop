package permitfolder;

import java.math.BigDecimal;

public class PricingCalculator {
    private static final BigDecimal SUV_MOD = new BigDecimal("1.15");
    private static final BigDecimal MC_MOD = new BigDecimal("0.70");
    private static final BigDecimal CARPOOL_MOD = new BigDecimal("0.90");
    private static final BigDecimal CAMPUS_FEE = new BigDecimal("5.00");

    private final PricingStrategy strategy;

    public PricingCalculator(PricingStrategy strategy) {
        this.strategy = strategy;
    }

    public Receipt calculate(PermitSelection sel) {
        BigDecimal monthly = strategy.baseMonthly(sel);

        switch (sel.getVehicleType()) {
            case SUV:
                monthly = monthly.multiply(SUV_MOD);
                break;
            case MOTORCYCLE:
                monthly = monthly.multiply(MC_MOD);
                break;
            default: break;
        }
        if (sel.isCarpool()) {
            monthly = monthly.multiply(CARPOOL_MOD);
        }
        monthly = monthly.setScale(2, BigDecimal.ROUND_HALF_UP);

        BigDecimal subtotal = monthly.multiply(BigDecimal.valueOf(sel.getMonths())).setScale(2, BigDecimal.ROUND_HALF_UP);
        BigDecimal campusFee = CAMPUS_FEE.setScale(2, BigDecimal.ROUND_HALF_UP);
        BigDecimal total = subtotal.add(campusFee).setScale(2, BigDecimal.ROUND_HALF_UP);

        return new Receipt(sel, monthly, subtotal, campusFee, total);
    }
}
