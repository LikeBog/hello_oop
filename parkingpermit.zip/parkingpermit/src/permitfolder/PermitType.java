package permitfolder;
	
public enum PermitType {	
    RESIDENT, COMMUTER
}
