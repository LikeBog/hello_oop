package permitfolder;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        while (true) {
            try {
                System.out.print("Select permit type (RESIDENT/COMMUTER): ");
                PermitType permitType = PermitType.valueOf(in.next().toUpperCase());
                System.out.print("Select vehicle type (CAR/SUV/MOTORCYCLE): ");
                VehicleType vehicleType = VehicleType.valueOf(in.next().toUpperCase());
                System.out.print("Are you carpooling? (Y/N): ");
                boolean carpool = in.next().trim().equalsIgnoreCase("Y");
                System.out.print("Number of months (1-12): ");
                int months = in.nextInt();

                PermitSelection sel = new PermitSelection(permitType, vehicleType, carpool, months);
                PricingStrategy strat = (permitType == PermitType.RESIDENT)
                        ? new ResidentPricingStrategy()
                        : new CommuterPricingStrategy();
                PricingCalculator calc = new PricingCalculator(strat);
                Receipt rec = calc.calculate(sel);

                System.out.println("\n--- Parking Permit Receipt ---");
                System.out.println("Permit: " + permitType);
                System.out.println("Vehicle: " + vehicleType);
                System.out.println("Carpool: " + (carpool ? "Yes" : "No"));
                System.out.println("Months: " + months);
                System.out.println("Monthly: $" + rec.monthly);
                System.out.println("Subtotal: $" + rec.subtotal);
                System.out.println("Campus fee: $" + rec.campusFee);
                System.out.println("Total: $" + rec.total);
                break;
            } catch (InvalidSelectionException ex) {
                System.out.println("Input error: " + ex.getMessage());
            } catch (Exception ex) {
                System.out.println("Invalid input, try again.");
                in.nextLine(); // clear buffer if int or enum fails
            }
        }
        in.close();
    }
}
