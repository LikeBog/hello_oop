package permitfolder;

public class PermitSelection implements Validatable {
    private final PermitType permitType;
    private final VehicleType vehicleType;
    private final boolean carpool;
    private final int months;

    public PermitSelection(PermitType permitType, VehicleType vehicleType, boolean carpool, int months) {
        this.permitType = permitType;
        this.vehicleType = vehicleType;
        this.carpool = carpool;
        this.months = months;
        validate();
    }

    @Override
    public void validate() {
        if (permitType == null)
            throw new InvalidSelectionException("Permit type required.");
        if (vehicleType == null)
            throw new InvalidSelectionException("Vehicle type required.");
        if (months < 1 || months > 12)
            throw new InvalidSelectionException("Months must be between 1 and 12.");
    }

    public PermitType getPermitType() { return permitType; }
    public VehicleType getVehicleType() { return vehicleType; }
    public boolean isCarpool() { return carpool; }
    public int getMonths() { return months; }
}
