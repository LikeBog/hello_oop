package permitfolder;

import java.math.BigDecimal;

public class Receipt {
    public final PermitSelection selection;
    public final BigDecimal monthly;
    public final BigDecimal subtotal;
    public final BigDecimal campusFee;
    public final BigDecimal total;

    public Receipt(PermitSelection selection, BigDecimal monthly, BigDecimal subtotal, BigDecimal campusFee, BigDecimal total) {
        this.selection = selection;
        this.monthly = monthly;
        this.subtotal = subtotal;
        this.campusFee = campusFee;
        this.total = total;
    }
}
