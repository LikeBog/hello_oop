package permitfolder;

import java.math.BigDecimal;

public class CommuterPricingStrategy implements PricingStrategy {
    public BigDecimal baseMonthly(PermitSelection sel) {
        // $35, automatic $15 discount
        return new BigDecimal("20.00");
    }
}
