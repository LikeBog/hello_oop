package permitfolder;
	
public interface Validatable {	
    void validate() throws InvalidSelectionException;
}
