package permitfolder;

public class InvalidSelectionException extends RuntimeException {
    public InvalidSelectionException(String message) {
        super(message);
    }
}
