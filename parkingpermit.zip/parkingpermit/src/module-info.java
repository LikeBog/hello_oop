/**
 * 
 */
/**
 * @author nlasz
 *
 */
module parkingpermit {
}